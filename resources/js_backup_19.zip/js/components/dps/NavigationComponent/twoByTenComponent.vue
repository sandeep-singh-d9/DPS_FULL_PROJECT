<template>
    <div class="row full_layer_row" @mouseover="getDynamicIndexOnHover">
         <div  class="full_data" >
            <HoverRow :indexId="dynamicIndex" />
            <div v-for="(divData, index) in dynamicHtml" :key="index" :class="{'col-sm-2':divData.className =='col-sm-2' ,
            'col-sm-10':divData.className =='col-sm-10', 'nineteen' : divData.type == 'nineteen', 'twenty' : divData.type == 'twenty', 'cell': true}" :id="divData.id"  :style="divData.style">
                <!-- buttons on hovers -->
                <!-----------------Conditional button--------------->
                <div class="icon_top_inner" v-if="divData.values[0].text =='' && divData.values[1].image =='' && divData.values[2].video ==''">
                        <i  class="ti-plus" @click="setInnerDyanamicIndex(index), addClick(divData.type, divData.id)"></i>
                </div>
                
                <iconHoverComponent  v-if="divData.values[0].text 
                || divData.values[1].image || divData.values[2].video" :divId="divData.id" :typeData="divData.type" :innerIndex="index" :mainIndex="dynamicIndex" />
                
                <DisplayDivData :divsdatacontent="divData"/>

                <div class="Copy_component"  v-if="divData.values[0].text 
                || divData.values[1].image || divData.values[2].video ">
                    <i class="ti-plus"  @click="copyDiv(divData.className, divData.type)"></i>
                </div>
                
            </div>
        </div>
        <!-- ADD Row Component -->
            <AddRow :mainIndex="dynamicIndex"/>
        <!-- ADD Row Component -->
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
