<template>
    <div>
        <div class="modal fade bd-example-modal-lg show_data background_image_color" id="colorImagePicker" tabindex="-1" role="dialog" aria-labelledby="colorImagePickerLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Background Select</h5>
                    </div>
                    <div class="modal-tab-content">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" class="active" href="#home">Background Color</a></li>
                            <li><a data-toggle="tab" href="#menu1">Background Image</a></li>
                        </ul>
                    </div>    
                    <div class="modal-body">
                        <div class="tab-content">
                            <div id="home" class="tab-pane active">
                                <color-picker class="color_picker_model" v-model="colorModel" @input="changeWholeBackground(colorModel)"> </color-picker>
                            </div>
                            <div id="menu1" class="tab-pane fade">
                                <!-- <div class=" background_image_component">
                                    <div class="col-sm-8">
                                        <div class="content_btn">
                                            <i class="far fa-images"></i>
                                            <br>Add Background Image 
                                        </div>
                                    </div>
                                </div> -->
                                <UplaodArea />
                            </div>
                        </div>   
                    </div>
                    <div class="modal-footer">
                        <div class="inner_footer_content" @click="closeModal">
                            <a class="btn two" data-dismiss="modal">
                                <i class="fa fa-window-close" aria-hidden="true"></i>
                            </a>
                            <a class="btn one" data-dismiss="modal">
                                <i class="fas fa-check"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import ColorPicker from "vue-iro-color-picker";
export default {
    data() {
        return{
            colorModel:"",
        }
    },
    components: {
        "color-picker": ColorPicker
    },
}
</script>

<style>

</style>
