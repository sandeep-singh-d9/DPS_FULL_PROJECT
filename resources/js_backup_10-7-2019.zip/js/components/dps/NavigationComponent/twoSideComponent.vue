<template>
  <div class="row full_layer_row" @mouseover="getDynamicIndexOnHover">
    <div  class="full_data" >
      <HoverRow :indexId="dynamicIndex" />
      <div v-for="(divData, index) in dynamicHtml" :key="index" :class="{'col-sm-6': divData.className =='col-sm-6' , 'two' : divData.type == 'two', 'three' : divData.type == 'three', 'cell': true}" :id="divData.id">
        <!-- buttons on hovers -->
        <div v-for="(divDataInner, key) in divData.values" :key="key">
          <div class="icon_top_inner" v-if="divDataInner.text==''">
            <i  class="fas fa-plus-circle" @click="setInnerDyanamicIndex(index), addClick(divData.type, divData.id)"></i>
          </div>
          <div class="Copy_component" v-if="divDataInner.text">
            <i class="fas fa-plus-circle"  @click="copyDiv(divData.className, divData.type)"></i>
          </div>
           <iconHoverComponent  v-if="divDataInner.text" :divId="divData.id" :typeData="divData.type" :innerIndex="index" :mainIndex="dynamicIndex" />
        </div> 
        <!-- <HoverButton :divsData="divData" /> -->
       
        <DisplayDivData :divsdatacontent="divData"/>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>



