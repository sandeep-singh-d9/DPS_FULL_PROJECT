<template>
    <div>
        <div v-for="(divDataInner, key) in divsData.values" :key="key">
            <div class="icon_top_inner" v-if="divDataInner.text == ''" >
                
                <i  class="fas fa-plus-circle" @click="addClick(divsData.type, divsData.id), setInnerDyanamicIndex(index)"></i>
            </div> 
            <div class="icon_top_inner Copy_component" v-if="divDataInner.text">
                
                <i class="fas fa-plus-circle" @click="copyDiv(divsData.className, divsData.type)"></i>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['divsData']

}
</script>

<style>

</style>
