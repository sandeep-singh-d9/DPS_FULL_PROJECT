<template>
    <div class="row full_layer_row" @mouseover="getDynamicIndexOnHover">
        <HoverRow :indexId="dynamicIndex" />
        <div  class="full_data" >
            <div :class="{'col-sm-4': divData.className =='col-sm-4' , 'four' : divData.type == 'four', 'five' : divData.type == 'five','six' : divData.type == 'six', 'cell': true}" v-for="(divData, index) in dynamicHtml" :key="index" :id="divData.id" >
                <!-- buttons on hovers -->

                 <!-----------------Conditional button--------------->
                    <div class="icon_top_inner" v-if="divData.values[0].text =='' && divData.values[1].image =='' && divData.values[2].video ==''">
                            <i  class="fas fa-plus-circle" @click="setInnerDyanamicIndex(index), addClick(divData.type, divData.id)"></i>
                    </div>
                    <div class="Copy_component"  v-if="divData.values[0].text 
                    || divData.values[1].image || divData.values[2].video ">
                        <i class="fas fa-plus-circle"  @click="copyDiv(divData.className, divData.type)"></i>
                    </div>
                    <iconHoverComponent  v-if="divData.values[0].text 
                    || divData.values[1].image || divData.values[2].video" :divId="divData.id" :typeData="divData.type" :innerIndex="index" :mainIndex="dynamicIndex" />
                <!-----------------Conditional button--------------->   
                <!-- <div v-for="(divDataInner, key) in divData.values" :key="key">
                    <div class="icon_top_inner" v-if="divDataInner.text==''">
                        <i  class="fas fa-plus-circle" @click="setInnerDyanamicIndex(index), addClick(divData.type, divData.id)"></i>
                    </div>
                    <div class="Copy_component" v-if="divDataInner.text">
                        <i class="fas fa-plus-circle"  @click="copyDiv(divData.className, divData.type)"></i>
                    </div>
                    <iconHoverComponent v-if="divDataInner.text" :divId="divData.id" :typeData="divData.type" :innerIndex="index" :mainIndex="dynamicIndex" />
                </div>  -->
                <DisplayDivData :divsdatacontent="divData"/>
             </div>
        </div>
        <!-- ADD Row Component -->
            <AddRow/>
        <!-- ADD Row Component -->
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
