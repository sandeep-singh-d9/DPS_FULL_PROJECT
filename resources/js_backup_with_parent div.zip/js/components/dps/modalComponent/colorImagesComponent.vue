<template>
    <div>
        <div class="modal fade bd-example-modal-lg show_data background_image_color" id="colorImagePicker" tabindex="-1" role="dialog" aria-labelledby="colorImagePickerLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Background Style</h5>
                    </div>
                    <div class="modal-tab-content ">
                        <ul class="nav nav-tabs content_btn">
                            <li class="active ">
                                <a data-toggle="tab" class="active" href="#home">
                                    <i class="ti-paint-bucket"></i><br/>Background Color
                                </a>
                            </li>
                            <li>
                                <a data-toggle="tab" href="#menu1">
                                    <i class="ti-image"></i><br/>Background Image
                                </a>
                            </li>
                        </ul>
                    </div>    
                    <div class="modal-body">
                        <div class="tab-content">
                            <div id="home" class="tab-pane active">
                                <div class="content_area">
                                    <!-- start text Color -->
                                    <!-- <div class="font_content">Text Color</div> -->
                                    <div class="font_body">
                                        <div class="col-sm-12">
                                            <color-picker class="color_picker_model" v-model="colorModel" @input="changeWholeBackground(colorModel)"> </color-picker>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="menu1" class="tab-pane fade">
                                <div class="content_area">
                                    <UplaodArea />
                                </div>
                            </div>
                        </div>   
                    </div>
                    <div class="modal-footer">
                        <div class="inner_footer_content" @click="closeModal">
                            <button class="btn bottom_btn width_half" data-dismiss="modal" @click="close_all_data">
								<i class="ti-close" aria-hidden="true" ></i>
							</button>
                            <button class="btn bottom_btn width_half" @click="applyChanges" data-dismiss="modal">
								<i class="ti-check"></i>
							</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import ColorPicker from "vue-iro-color-picker";
export default {
    data() {
        return{
            colorModel:"",
        }
    },
    mounted(){
       $("#colorImagePicker").modal({
			focus: false,
			// Do not show modal when innitialized.
			show: false,
			backdrop: 'static', // For static modal
			keyboard: false // prevent click outside of the modal
		});
    },
    components: {
        "color-picker": ColorPicker
    },
}
</script>

<style>

</style>
