<template>
    <div>
        <div class="inner_plus_data">
        <i class="fas fa-cog"></i>
        <i class="far fa-clone"></i>
        <i class="fas fa-trash-alt"></i>
      </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
